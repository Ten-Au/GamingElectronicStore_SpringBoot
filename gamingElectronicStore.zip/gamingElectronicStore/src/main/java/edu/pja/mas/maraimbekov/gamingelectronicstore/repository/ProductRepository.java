package edu.pja.mas.maraimbekov.gamingelectronicstore.repository;

import edu.pja.mas.maraimbekov.gamingelectronicstore.model.Product;
import org.springframework.data.repository.CrudRepository;

public interface ProductRepository extends CrudRepository<Product, Long> {

}
