package edu.pja.mas.maraimbekov.gamingelectronicstore.repository;

import edu.pja.mas.maraimbekov.gamingelectronicstore.model.WiredController;
import org.springframework.data.repository.CrudRepository;

public interface WiredControllerRepository extends CrudRepository<WiredController, Long> {
}
