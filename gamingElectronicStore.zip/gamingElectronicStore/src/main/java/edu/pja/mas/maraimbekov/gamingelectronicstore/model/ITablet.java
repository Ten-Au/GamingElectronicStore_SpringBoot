package edu.pja.mas.maraimbekov.gamingelectronicstore.model;

public interface ITablet {
    double getTouchScreenResponseTime();
    void setTouchScreenResponseTime(double touchScreenResponseTime);
}
