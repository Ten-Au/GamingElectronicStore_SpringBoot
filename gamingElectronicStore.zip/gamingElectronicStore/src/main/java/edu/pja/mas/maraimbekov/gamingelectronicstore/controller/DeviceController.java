package edu.pja.mas.maraimbekov.gamingelectronicstore.controller;

import edu.pja.mas.maraimbekov.gamingelectronicstore.model.Device;
import edu.pja.mas.maraimbekov.gamingelectronicstore.model.Product;
import edu.pja.mas.maraimbekov.gamingelectronicstore.model.StationaryComputer;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.ArrayList;
import java.util.List;


@Controller

@RequestMapping("/device")
public class DeviceController {

    private List<Device> deviceList;

    @PostConstruct
    private void loadData() {
        Device device = StationaryComputer.builder()
                .name("Razor")
                .price(300)
                .operatingSystem("Windows 11")
                .serialNumber("ADANA")
                .monitorIncluded(true)
                .build();

        deviceList = new ArrayList<>();

        deviceList.add(device);
    }

    @GetMapping("/")
    public String showDevices(Model model) {
        model.addAttribute("devices", deviceList);
        return "device-list";
    }

}
