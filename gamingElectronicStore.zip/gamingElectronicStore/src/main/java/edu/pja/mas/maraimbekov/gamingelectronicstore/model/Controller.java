package edu.pja.mas.maraimbekov.gamingelectronicstore.model;


import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.EnumSet;

@EqualsAndHashCode(callSuper = true)
@Entity
@Data
@Inheritance(strategy = InheritanceType.JOINED)
@NoArgsConstructor
@SuperBuilder
@ToString
public class Controller extends Product {

    //General information
    @Min(0)
    private int numOfKeys;

    //Overlapping by type aspect
    @NotNull
    @Lob
    @Setter(AccessLevel.PRIVATE)
    @Column(updatable = false, nullable = false)
    private EnumSet<ControllerType> controllerTypes;

    //Gamepad type information
    @Min(0)
    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    private Integer numOfBacksideButtons;

    //Joystick type information
    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    private String stickType;

    public Controller(int numOfKeys, EnumSet<ControllerType> controllerTypes,
                      Integer numOfBacksideButtons, String stickType) {
        setNumOfKeys(numOfKeys);
        setControllerTypes(controllerTypes);

        if (controllerTypes.contains(ControllerType.GAMEPAD)) {
            setNumOfBacksideButtons(numOfBacksideButtons);
        }
        if (controllerTypes.contains(ControllerType.JOYSTICK)) {
            setStickType(stickType);
        }
    }

    //Polymorphic inheritance from Product
    @Override
    public void showDetails() {
        System.out.println("Number of keys: " + numOfKeys);

        if (controllerTypes.contains(ControllerType.JOYSTICK)) {
            System.out.println("Stick type: " + stickType);
        }
        if (controllerTypes.contains(ControllerType.GAMEPAD)) {
            System.out.println("Num of backside buttons: " + numOfBacksideButtons);
        }
    }

    public Integer getNumOfBacksideButtons() {
        if (!controllerTypes.contains(ControllerType.GAMEPAD)) {
            throw new IllegalArgumentException("Wrong type");
        }
        return numOfBacksideButtons;
    }

    public String getStickType() {
        if (!controllerTypes.contains(ControllerType.JOYSTICK)) {
            throw new IllegalArgumentException("Wrong type");
        }
        return stickType;
    }

    public void setNumOfBacksideButtons(Integer numOfBacksideButtons) {
        if (!controllerTypes.contains(ControllerType.GAMEPAD)) {
            throw new IllegalArgumentException("Wrong type");
        }
        if (numOfBacksideButtons == null) {
            throw new IllegalArgumentException("Cant be null");
        }
        if (numOfBacksideButtons < 0) {
            throw new IllegalArgumentException("Cannot be less 0");
        }
        this.numOfBacksideButtons = numOfBacksideButtons;
    }

    public void setStickType(String stickType) {
        if (!controllerTypes.contains(ControllerType.JOYSTICK)) {
            throw new IllegalArgumentException("Wrong type");
        }
        if (stickType == null || stickType.trim().equals("")) {
            throw new IllegalArgumentException("Cant be null");
        }
        this.stickType = stickType;
    }
}
