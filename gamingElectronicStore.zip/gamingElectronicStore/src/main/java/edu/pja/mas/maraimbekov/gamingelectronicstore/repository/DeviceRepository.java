package edu.pja.mas.maraimbekov.gamingelectronicstore.repository;

import edu.pja.mas.maraimbekov.gamingelectronicstore.model.Device;
import edu.pja.mas.maraimbekov.gamingelectronicstore.model.Store;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface DeviceRepository extends CrudRepository<Device, Long> {
    List<Device> findAllByOnSaleAt(Store store);
    Optional<Device> findById(Long id);

    List<Device> findAllByName(String name);

}
