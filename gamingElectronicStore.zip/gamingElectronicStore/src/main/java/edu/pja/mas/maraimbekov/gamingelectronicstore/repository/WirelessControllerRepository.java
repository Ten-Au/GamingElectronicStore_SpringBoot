package edu.pja.mas.maraimbekov.gamingelectronicstore.repository;

import edu.pja.mas.maraimbekov.gamingelectronicstore.model.WirelessController;
import org.springframework.data.repository.CrudRepository;

public interface WirelessControllerRepository extends CrudRepository<WirelessController, Long> {
}
