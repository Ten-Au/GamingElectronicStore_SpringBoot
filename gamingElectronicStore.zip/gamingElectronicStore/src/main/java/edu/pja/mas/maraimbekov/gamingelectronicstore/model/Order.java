package edu.pja.mas.maraimbekov.gamingelectronicstore.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import lombok.*;

import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "order_table")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Min(0)
    private long orderNumber;

    @Setter(AccessLevel.NONE)
    private String promoCode;

    @Min(0)
    private float totalPrice;

    @NotEmpty
    private String deliveryType;

    @Column(nullable = false)
    private OrderStatus orderStatus;

    //Class attribute - used promoCodes
    @ElementCollection
    @CollectionTable(name = "used_promocodes", joinColumns = @JoinColumn(name = "order_id"))
    @Builder.Default
    private static Set<String> usedPromoCodes = new HashSet<>();

    //Basic association - with Store
    @ManyToOne
    @JoinColumn(name = "store_id", nullable = false)
    @EqualsAndHashCode.Exclude
    private Store handledBy;

    //Basic association - with Customer
    @ManyToOne
    @JoinColumn(name = "person_id", nullable = false)
    @EqualsAndHashCode.Exclude
    private Person placedBy;

    @ManyToMany
    @JoinTable(
            name = "contains_product",
            joinColumns = @JoinColumn(name = "order_id"),
            inverseJoinColumns = @JoinColumn(name = "product_id"))
    private Set<Product> contains = new HashSet<>();

    //Mandatory attributes constructor
    public Order(long orderNumber, float totalPrice, String deliveryType) {
        setOrderNumber(orderNumber);
        setTotalPrice(totalPrice);
        setDeliveryType(deliveryType);
        setOrderStatus(orderStatus);
        this.orderStatus = OrderStatus.NEW;
    }
    //All attributes constructor
    public Order(long orderNumber, String promoCode, float totalPrice, String deliveryType) {
        setOrderNumber(orderNumber);
        setPromoCode(promoCode);
        setTotalPrice(totalPrice);
        setDeliveryType(deliveryType);
        setOrderStatus(orderStatus);
        this.orderStatus = OrderStatus.NEW;
    }
    public void setPromoCode(String promoCode) {
        if (promoCode.trim().equals("")) {
            throw new IllegalArgumentException("Promocode cannot be empty");
        }
        if (usedPromoCodes.contains(promoCode)) {
            throw new IllegalArgumentException("This promocode is already used");
        }
        usedPromoCodes.add(promoCode);
        this.promoCode = promoCode;
    }
}
