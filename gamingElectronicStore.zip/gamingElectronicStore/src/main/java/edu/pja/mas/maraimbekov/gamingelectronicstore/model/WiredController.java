package edu.pja.mas.maraimbekov.gamingelectronicstore.model;


import jakarta.persistence.Entity;
import jakarta.validation.constraints.Min;
import lombok.*;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
@ToString
public class WiredController extends Controller {

    @Min(0)
    private double wireWidth;

}
