package edu.pja.mas.maraimbekov.gamingelectronicstore.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotEmpty;
import lombok.*;

import java.util.HashSet;
import java.util.Set;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Warehouse {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotEmpty(message = "Address required")
    private String address;


    //XOR constraint - association with Device
    @OneToMany(mappedBy = "storedIn", fetch = FetchType.LAZY, targetEntity = Device.class)
    @Builder.Default
    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    private Set<Device> devices = new HashSet<>();

    public void addDevice(Device device) {
        if (device == null) {
            throw new IllegalArgumentException("Device cannot be null");
        }
        if (device.getOnSaleAt() != null) {
            throw new IllegalArgumentException("Device has store");
        }
        if (this.devices.contains(device)) {
            return;
        }
        this.devices.add(device);
        device.setWarehouse(this);
    }

    public void removeDevice(Device device) {
        if (device == null) {
            throw new IllegalArgumentException("Device cannot be null");
        }
        if (!this.devices.contains(device)) {
            throw new IllegalArgumentException("Cannot remove not existing device");
        }
        this.devices.remove(device);
        device.setWarehouse(null);
    }
}
