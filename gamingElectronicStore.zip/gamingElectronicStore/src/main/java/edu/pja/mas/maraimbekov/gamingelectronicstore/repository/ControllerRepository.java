package edu.pja.mas.maraimbekov.gamingelectronicstore.repository;

import edu.pja.mas.maraimbekov.gamingelectronicstore.model.Controller;
import org.springframework.data.repository.CrudRepository;

public interface ControllerRepository extends CrudRepository<Controller, Long> {

}
