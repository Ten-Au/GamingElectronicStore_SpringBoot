package edu.pja.mas.maraimbekov.gamingelectronicstore.model;

public enum PersonType {
    ADMINISTRATOR,
    CUSTOMER,
    CASHIER
}
