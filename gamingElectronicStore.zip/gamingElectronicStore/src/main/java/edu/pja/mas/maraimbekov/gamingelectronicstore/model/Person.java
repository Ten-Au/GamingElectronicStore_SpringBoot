package edu.pja.mas.maraimbekov.gamingelectronicstore.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

@Entity
@Data
@NoArgsConstructor
@Inheritance(strategy = InheritanceType.JOINED)
@SuperBuilder
public class Person {

    //General information
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotEmpty(message = "Person name must be specified")
    private String name;
    @NotEmpty(message = "Person surname must be specified")
    private String surname;

    @NotNull
    private LocalDate dateOfBirth;

    //Dynamic inheritance - Person type
    @NotNull
    @Setter(AccessLevel.NONE)
    @Column(nullable = false)
    private PersonType personType;

    //Customer information
    @Setter(AccessLevel.NONE)
    private LocalDate dateOfRegistration;

    @Setter(AccessLevel.NONE)
    private String address;

    //Basic association - with Order
    @OneToMany(mappedBy = "placedBy", cascade = CascadeType.REMOVE)
    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    @Setter(AccessLevel.NONE)
    private Set<Order> orders = new HashSet<>();

    //Basic association with Bag constraint - with Store through Employment
    @OneToMany(mappedBy = "employee", cascade = CascadeType.REMOVE)
    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    private Set<Employment> employments = new HashSet<>();

    //Administrator information
    @Setter(AccessLevel.NONE)
    private String experienceLevel;

    //Cashier information
    @Min(0)
    @Setter(AccessLevel.NONE)
    private Double salaryBonus;

    private Person(String name, String surname, LocalDate dateOfBirth) {
        setName(name);
        setSurname(surname);
        setDateOfBirth(dateOfBirth);
    }

    public static Person createNewAdministrator(String name, String surname,
                                                LocalDate dateOfBirth, String experienceLevel) {
        Person person = new Person(name, surname, dateOfBirth);
        person.makeAdministrator(experienceLevel);
        return person;
    }

    public static Person createNewCustomer(String name, String surname,
                                                LocalDate dateOfBirth, String address) {
        Person person = new Person(name, surname, dateOfBirth);
        person.makeCustomer(address);
        return person;
    }
    public static Person createNewCashier(String name, String surname,
                                                LocalDate dateOfBirth, Double salaryBonus) {
        Person person = new Person(name, surname, dateOfBirth);
        person.makeCashier(salaryBonus);
        return person;
    }

    public void makeAdministrator(String experienceLevel) {
        this.personType = PersonType.ADMINISTRATOR;
        setExperienceLevel(experienceLevel);
        this.dateOfRegistration = null;
        this.address = null;
        this.salaryBonus = null;
    }

    public void makeCustomer(String address) {
        this.personType = PersonType.CUSTOMER;
        setAddress(address);
        this.dateOfRegistration = LocalDate.now();
        this.salaryBonus = null;
        this.experienceLevel = null;
    }

    public void makeCashier(Double salaryBonus) {
        this.personType = PersonType.CASHIER;
        setSalaryBonus(salaryBonus);
        this.experienceLevel = null;
        this.dateOfRegistration = null;
        this.address = null;
    }

    public String getExperienceLevel() {
        if(!(personType == PersonType.ADMINISTRATOR)) {
            throw new IllegalArgumentException("Wrong type");
        }
        return experienceLevel;
    }
    public void setExperienceLevel(String experienceLevel) {
        if(!(personType == PersonType.ADMINISTRATOR)) {
            throw new IllegalArgumentException("Wrong type");
        }
        if (experienceLevel == null || experienceLevel.trim().equals("")) {
            throw new IllegalArgumentException("No experience Level specified");
        }
        this.experienceLevel = experienceLevel;
    }

    public String getAddress() {
        if(!(personType == PersonType.CUSTOMER)) {
            throw new IllegalArgumentException("Wrong type");
        }
        return address;
    }

    public void setAddress(String address) {
        if(!(personType == PersonType.CUSTOMER)) {
            throw new IllegalArgumentException("Wrong type");
        }
        if (address == null || address.trim().equals("")) {
            throw new IllegalArgumentException("No address specified");
        }
        this.address = address;
    }

    public Double getSalaryBonus() {
        if(!(personType == PersonType.CASHIER)) {
            throw new IllegalArgumentException("Wrong type");
        }
        return salaryBonus;
    }

    public void setSalaryBonus(Double salaryBonus) {
        if(!(personType == PersonType.CASHIER)) {
            throw new IllegalArgumentException("Wrong type");
        }
        if (salaryBonus == null) {
            throw new IllegalArgumentException("No salary bonus specified");
        }
        if (salaryBonus < 0) {
            throw new IllegalArgumentException("Should be more than 0");
        }
        this.salaryBonus = salaryBonus;
    }
}
