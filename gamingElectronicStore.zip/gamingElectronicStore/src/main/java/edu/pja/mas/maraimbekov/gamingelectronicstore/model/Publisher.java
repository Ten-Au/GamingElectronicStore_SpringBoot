package edu.pja.mas.maraimbekov.gamingelectronicstore.model;


import jakarta.persistence.*;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Publisher {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotEmpty(message = "Publisher name is required")
    private String name;

    @NotNull(message = "Game comparator should be specified")
    private static Comparator<Game> gameComparator =  Comparator.comparing(Game::getName);

    @OneToMany(mappedBy = "publisher", cascade = CascadeType.REMOVE)
    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    @Builder.Default
    private Set<Game> games = new HashSet<>();

    public List<Game> getGameList() {
        return games.stream()
                .sorted(gameComparator).toList();
    }

}
