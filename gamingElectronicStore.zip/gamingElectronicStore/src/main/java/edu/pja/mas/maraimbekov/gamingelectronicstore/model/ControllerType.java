package edu.pja.mas.maraimbekov.gamingelectronicstore.model;

public enum ControllerType {
    GAMEPAD,
    JOYSTICK
}
