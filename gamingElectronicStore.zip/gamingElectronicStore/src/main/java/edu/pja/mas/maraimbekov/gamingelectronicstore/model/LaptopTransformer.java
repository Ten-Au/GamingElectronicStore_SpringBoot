package edu.pja.mas.maraimbekov.gamingelectronicstore.model;


import jakarta.persistence.Entity;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder

public class LaptopTransformer extends Laptop implements ITablet {

    @DecimalMin("0.1")
    @DecimalMax("10")
    private double touchScreenResponseTime;

    @DecimalMin("0")
    private double maxTransformAngle;

    @Override
    public double getTouchScreenResponseTime() {
        return touchScreenResponseTime;
    }

    @Override
    public void setTouchScreenResponseTime(double touchScreenResponseTime) {
        if (touchScreenResponseTime < 0.1 || touchScreenResponseTime > 10) {
            throw new IllegalArgumentException("Touch screen resp. time cannot be more than 10 or less than 0.1");
        }
        this.touchScreenResponseTime = touchScreenResponseTime;
    }

}
