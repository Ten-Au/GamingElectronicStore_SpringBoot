package edu.pja.mas.maraimbekov.gamingelectronicstore.model;

import jakarta.persistence.Entity;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class Console extends Device{

    @NotBlank(message = "Best TV comp. is required")
    private String bestTvCompatibility;

    //Polymorphic inheritance from Product
    @Override
    public void showDetails() {
        System.out.println("Best compatible with: " + bestTvCompatibility);
    }

    //Polymorphic inheritance from Device
    @Override
    public double calculateDurabilityInYears() {
        return switch (bestTvCompatibility) {
            case "LG" -> 2;
            case "Samsung" -> 1.5;
            case "Philips" -> 3;
            default -> 2.5;
        };
    }
}
