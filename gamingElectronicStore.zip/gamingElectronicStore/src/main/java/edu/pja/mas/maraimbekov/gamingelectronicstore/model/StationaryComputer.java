package edu.pja.mas.maraimbekov.gamingelectronicstore.model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import lombok.*;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
@ToString
public class StationaryComputer extends Device{


    private boolean monitorIncluded;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "benchmark_id", referencedColumnName = "id")
    private Benchmark benchmark;

    //Polymorphic inheritance from Product
    @Override
    public void showDetails() {
        if (monitorIncluded) {
            System.out.println("Monitor included");
        } else {
            System.out.println("Monitor is not included");
        }
        System.out.println("Benchmark: " + benchmark);
    }
    //Polymorphic inheritance from Device
    @Override
    public double calculateDurabilityInYears() {
        return benchmark.getAvgFPS() * 2/6;
    }
}
