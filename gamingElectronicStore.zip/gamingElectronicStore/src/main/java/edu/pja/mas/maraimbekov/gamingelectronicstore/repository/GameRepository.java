package edu.pja.mas.maraimbekov.gamingelectronicstore.repository;

import edu.pja.mas.maraimbekov.gamingelectronicstore.model.Game;
import org.springframework.data.repository.CrudRepository;

public interface GameRepository extends CrudRepository<Game, Long> {

}
