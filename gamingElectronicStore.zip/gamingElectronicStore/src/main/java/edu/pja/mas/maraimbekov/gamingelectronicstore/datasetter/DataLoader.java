package edu.pja.mas.maraimbekov.gamingelectronicstore.datasetter;

import edu.pja.mas.maraimbekov.gamingelectronicstore.model.*;
import edu.pja.mas.maraimbekov.gamingelectronicstore.repository.DeviceRepository;
import edu.pja.mas.maraimbekov.gamingelectronicstore.repository.StoreRepository;
import lombok.AllArgsConstructor;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@AllArgsConstructor
public class DataLoader implements ApplicationRunner {

    private final DeviceRepository deviceRepository;
    private final StoreRepository storeRepository;

    @Override
    public void run(ApplicationArguments args) throws Exception {
        deviceRepository.deleteAll();
        storeRepository.deleteAll();

        Store store = Store.builder()
                .monthlyIncome(300)
                .monthlyExpenses(200)
                .address("Somewhere outside")
                .build();
        Store store1 = Store.builder()
                .monthlyIncome(700)
                .monthlyExpenses(100)
                .address("Somewhere near")
                .build();

        Device device = Laptop.builder()
                .name("Ryzer 100")
                .price(323)
                .operatingSystem("Linux")
                .serialNumber("FJKDS3")
                .matrixType("Good matrix")
                .onSaleAt(store)
                .build();
        Device device1 = Laptop.builder()
                .name("Red bull")
                .price(323)
                .operatingSystem("Windows")
                .serialNumber("FLDD02")
                .matrixType("Bad matrix")
                .onSaleAt(store)
                .build();
        Device device2 = Laptop.builder()
                .name("Compiler 3000")
                .price(323)
                .serialNumber("SASm32")
                .matrixType("Avg matrix")
                .onSaleAt(store)
                .build();
        Device device3 = Laptop.builder()
                .name("macbook 222")
                .price(323)
                .operatingSystem("Mac")
                .serialNumber("DSDS333")
                .matrixType("Retina")
                .onSaleAt(store1)
                .build();
        Device device4 = Tablet.builder()
                .name("Toucher 22")
                .price(300)
                .operatingSystem("Super")
                .serialNumber("FDF412")
                .touchScreenResponseTime(6)
                .onSaleAt(store)
                .build();


        storeRepository.saveAll(List.of(store, store1));
        deviceRepository.saveAll(List.of(device, device1, device2, device3, device4));

    }
}
