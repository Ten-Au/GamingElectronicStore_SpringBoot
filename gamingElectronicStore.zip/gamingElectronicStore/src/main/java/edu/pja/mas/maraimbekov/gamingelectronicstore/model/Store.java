package edu.pja.mas.maraimbekov.gamingelectronicstore.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import lombok.*;

import java.util.*;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Store {


    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Min(0)
    private float monthlyIncome;

    @Min(0)
    private float monthlyExpenses;

    @NotEmpty(message = "Address required")
    private String address;

    //Basic association - with Order
    @OneToMany(mappedBy = "handledBy", cascade = CascadeType.REMOVE)
    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    @Builder.Default
    private Map<Long, Order> orders = new HashMap<>();

    //Association with an Attribute - with Game
    @OneToMany(mappedBy = "store", cascade = {CascadeType.REMOVE})
    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    @Builder.Default
    private Set<GameVersion> gameVersions = new HashSet<>();

    //Basic association with Bag constraint - with Person through Employment
    @OneToMany(mappedBy = "store", cascade = CascadeType.REMOVE)
    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    @Builder.Default
    private Set<Employment> employments = new HashSet<>();

    //XOR constraint - association with Device
    @OneToMany(mappedBy = "onSaleAt", fetch = FetchType.LAZY, targetEntity = Device.class)
    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    @Builder.Default
    private Set<Device> devices = new HashSet<>();

    public void addDevice(Device device) {
        if (device == null) {
            throw new IllegalArgumentException("Device cannot be null");
        }
        if (device.getStoredIn() != null) {
            throw new IllegalArgumentException("Device already belongs to warehouse");
        }
        if (this.devices.contains(device)) {
            return;
        }
        this.devices.add(device);
        device.setStore(this);
    }

    public void removeDevice(Device device) {
        if (device == null) {
            throw new IllegalArgumentException("Device cannot be null");
        }
        if (!this.devices.contains(device)) {
            throw new IllegalArgumentException("Cannot remove not existing device");
        }
        this.devices.remove(device);
        device.setStore(null);
    }


    //Derived attribute
    public float getTotalMonthlyProfit() {
        return monthlyIncome - monthlyExpenses;
    }

    public List<Order> getOrderList() {
        return new ArrayList<>(orders.values());
    }
    public Order getOrder(long id) {
        return orders.get(id);
    }
}
