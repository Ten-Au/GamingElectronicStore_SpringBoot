package edu.pja.mas.maraimbekov.gamingelectronicstore.model;


import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.HashSet;
import java.util.Set;

@EqualsAndHashCode(callSuper = true)
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
@ToString
public class Game extends Product {

    //Multi-value attribute - game genres
    @ElementCollection
    @CollectionTable(name = "game_genre", joinColumns = @JoinColumn(name = "game_id"))
    @Builder.Default
    private Set<String> genres = new HashSet<>();

    //Class attribute - known game genres
    @ElementCollection
    @CollectionTable(name = "known_game_genres", joinColumns = @JoinColumn(name = "game_id"))
    @Builder.Default
    public static Set<String> knownGenres = new HashSet<>();

    //Composition association - with Publisher
    @ManyToOne(optional = false)
    @JoinColumn(name = "publisher_id", nullable = false, updatable = false)
    private Publisher publisher;

    //Association with an Attribute - with Store
    @OneToMany(mappedBy = "game", cascade = {CascadeType.REMOVE})
    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    private Set<GameVersion> gameVersions;

    @Override
    public void showDetails() {
        System.out.println("Game genres: " + genres.toString());
    }
}
