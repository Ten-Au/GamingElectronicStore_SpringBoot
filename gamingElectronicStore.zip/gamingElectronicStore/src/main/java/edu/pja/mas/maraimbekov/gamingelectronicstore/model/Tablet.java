package edu.pja.mas.maraimbekov.gamingelectronicstore.model;

import jakarta.persistence.Entity;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class Tablet extends Device implements ITablet{

    @DecimalMin("0.1")
    @DecimalMax("10")
    private double touchScreenResponseTime;

    //Polymorphic inheritance from Product
    @Override
    public void showDetails() {
        System.out.println("Touch screen response time: " + touchScreenResponseTime);
    }
    //Polymorphic inheritance from Device
    @Override
    public double calculateDurabilityInYears() {
        if (touchScreenResponseTime < 5) {
            return (touchScreenResponseTime + 3)/2;
        } else {
            return touchScreenResponseTime/5;
        }
    }
}
