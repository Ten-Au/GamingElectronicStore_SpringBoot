package edu.pja.mas.maraimbekov.gamingelectronicstore.controller;

import edu.pja.mas.maraimbekov.gamingelectronicstore.model.Device;
import edu.pja.mas.maraimbekov.gamingelectronicstore.model.StationaryComputer;
import edu.pja.mas.maraimbekov.gamingelectronicstore.model.Store;
import edu.pja.mas.maraimbekov.gamingelectronicstore.repository.DeviceRepository;
import edu.pja.mas.maraimbekov.gamingelectronicstore.service.StoreDeviceService;
import jakarta.annotation.PostConstruct;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.ArrayList;
import java.util.List;

@Controller

@RequestMapping("/")

@AllArgsConstructor
public class StoreController {

   private final StoreDeviceService storeService;


    @PostConstruct
    private void loadData() {
    }

    @GetMapping("/stores")
    public String showStores(Model model) {
        model.addAttribute("stores", storeService.getAllStores());
        return "start-page";
    }

    @GetMapping("/stores/{id}/devices")
    public String showDevicesByStoreId(Model model, @PathVariable Long id) {
        model.addAttribute("devices", storeService.getDevicesByStoreId(id));
        return "device-list";
    }




}
