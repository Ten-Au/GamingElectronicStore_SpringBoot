package edu.pja.mas.maraimbekov.gamingelectronicstore.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.HashSet;

@EqualsAndHashCode(callSuper = true)
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Inheritance(strategy = InheritanceType.JOINED)
@SuperBuilder
public abstract class Device extends Product{


    //Optional attribute
    private String operatingSystem;

    //Unique attribute constraint
    @NotBlank(message = "Serial number is mandatory")
    @Size(min = 5, max = 10)
    @Column(name = "SERIALNUMBER", unique = true)
    private String serialNumber;


    //XOR constraint

    //Store association
    @ManyToOne
    @JoinColumn(name = "store_id")
    @EqualsAndHashCode.Exclude
    @Setter(AccessLevel.NONE)
    private Store onSaleAt;

    //Warehouse association
    @ManyToOne
    @JoinColumn(name = "warehouse_id")
    @EqualsAndHashCode.Exclude
    @Setter(AccessLevel.NONE)
    private Warehouse storedIn;

    public Device(String name, double price, String serialNumber) {
        setName(name);
        setPrice(price);
        setSerialNumber(serialNumber);
    }

    public void setStore(Store onSaleAt) {
        if (this.onSaleAt == onSaleAt) {
            return;
        }
        if (onSaleAt == null) {
            throw new IllegalArgumentException("Store cannot be null");
        }
        if (this.storedIn != null) {
            this.storedIn.getDevices().remove(this);
            this.storedIn = null;
        }
        this.onSaleAt = onSaleAt;
        onSaleAt.addDevice(this);
    }

    public void setWarehouse(Warehouse storedIn) {
        if (this.storedIn == storedIn) {
            return;
        }
        if (storedIn == null) {
            throw new IllegalArgumentException("Warehouse cannot be null");
        }
        if (this.onSaleAt != null) {
            this.onSaleAt.getDevices().remove(this);
            this.onSaleAt = null;
        }
        this.storedIn = storedIn;
        storedIn.addDevice(this);
    }

    public abstract double calculateDurabilityInYears();

}
