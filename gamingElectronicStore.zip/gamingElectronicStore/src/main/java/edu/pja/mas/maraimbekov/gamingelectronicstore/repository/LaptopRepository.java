package edu.pja.mas.maraimbekov.gamingelectronicstore.repository;

import edu.pja.mas.maraimbekov.gamingelectronicstore.model.Laptop;
import org.springframework.data.repository.CrudRepository;

public interface LaptopRepository extends CrudRepository<Laptop, Long> {
}
