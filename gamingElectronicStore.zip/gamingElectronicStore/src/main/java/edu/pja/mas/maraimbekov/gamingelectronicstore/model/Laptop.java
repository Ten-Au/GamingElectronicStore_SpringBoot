package edu.pja.mas.maraimbekov.gamingelectronicstore.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@Entity
@Data
@Inheritance(strategy = InheritanceType.JOINED)
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class Laptop extends Device {

    @NotBlank(message = "Matrix type required")
    private String matrixType;


    //Polymorphic inheritance from Product
    @Override
    public void showDetails() {
        System.out.println("Matrix type: " + matrixType);
    }

    //Polymorphic inheritance from Device
    @Override
    public double calculateDurabilityInYears() {
        if (matrixType.equals("Retina")) {
            return (float) (35/10*0.5)*15;
        } else if (matrixType.equals("Unibody")) {
            return (float) (18/10*0.05);
        } else {
            return (float) (250/10*0.5);
        }
    }
}
