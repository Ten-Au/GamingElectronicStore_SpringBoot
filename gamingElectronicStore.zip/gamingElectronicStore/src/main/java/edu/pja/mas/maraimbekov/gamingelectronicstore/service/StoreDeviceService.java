package edu.pja.mas.maraimbekov.gamingelectronicstore.service;


import edu.pja.mas.maraimbekov.gamingelectronicstore.model.Device;
import edu.pja.mas.maraimbekov.gamingelectronicstore.model.Store;
import edu.pja.mas.maraimbekov.gamingelectronicstore.repository.DeviceRepository;
import edu.pja.mas.maraimbekov.gamingelectronicstore.repository.StoreRepository;
import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
@AllArgsConstructor
public class StoreDeviceService {

    private final StoreRepository storeRepository;
    private final DeviceRepository deviceRepository;

    public List<Device> getDevicesByStoreId(Long id) {
        Store chosenStore = storeRepository.findFirstById(id);
        List<Device> devices = deviceRepository.findAllByOnSaleAt(chosenStore);

        return devices;
    }

    public List<Store> getAllStores() {
        return (List<Store>) storeRepository.findAll();
    }

    public Optional<Device> fetchDeviceDetails(Long id) {
        return deviceRepository.findById(id);
    }

    public void removeDevice(Long id) {
        Optional<Device> device = deviceRepository.findById(id);
        if (device.isPresent()) {
        }
    }


}
