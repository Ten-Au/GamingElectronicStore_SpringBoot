package edu.pja.mas.maraimbekov.gamingelectronicstore.repository;

import edu.pja.mas.maraimbekov.gamingelectronicstore.model.Benchmark;
import org.springframework.data.repository.CrudRepository;

public interface BenchmarkRepository extends CrudRepository<Benchmark, Long> {
}
