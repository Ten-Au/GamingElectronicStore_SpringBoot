package edu.pja.mas.maraimbekov.gamingelectronicstore.model;

import jakarta.persistence.Entity;
import jakarta.validation.constraints.NotEmpty;
import lombok.*;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
@ToString
public class WirelessController extends Controller {

    @NotEmpty(message = "Connection method required")
    private String connectionMethod;

}
