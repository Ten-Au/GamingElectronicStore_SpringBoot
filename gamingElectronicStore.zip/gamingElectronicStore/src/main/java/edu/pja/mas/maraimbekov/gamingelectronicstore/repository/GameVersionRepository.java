package edu.pja.mas.maraimbekov.gamingelectronicstore.repository;

import edu.pja.mas.maraimbekov.gamingelectronicstore.model.GameVersion;
import org.springframework.data.repository.CrudRepository;

public interface GameVersionRepository extends CrudRepository<GameVersion, Long> {
}
