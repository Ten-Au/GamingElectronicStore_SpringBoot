package edu.pja.mas.maraimbekov.gamingelectronicstore.model;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Benchmark {

    @Id
    @GeneratedValue
    private Long id;

    @NotBlank(message = "GPU info is mandatory")
    private String gpuOverall;

    @NotBlank(message = "CPU info is mandatory")
    private String cpuOverall;

    @DecimalMin("15")
    @DecimalMax("300")
    private double avgFPS;

    @OneToOne(mappedBy = "benchmark")
    private StationaryComputer stationaryComputer;

}
