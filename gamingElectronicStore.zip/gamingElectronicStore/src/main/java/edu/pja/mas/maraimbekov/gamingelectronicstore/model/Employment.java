package edu.pja.mas.maraimbekov.gamingelectronicstore.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import lombok.*;

import java.time.LocalDate;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Employment {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(nullable = false)
    private LocalDate date;

    @Min(0)
    private double salary;

    //Association with Person
    @ManyToOne
    @JoinColumn(name = "employee_id", nullable = false)
    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    private Person employee;

    //Association with Store
    @ManyToOne
    @JoinColumn(name = "store_id", nullable = false)
    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    private Store store;


}
