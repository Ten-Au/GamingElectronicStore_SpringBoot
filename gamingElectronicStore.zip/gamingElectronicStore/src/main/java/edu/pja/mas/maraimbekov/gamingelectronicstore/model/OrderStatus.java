package edu.pja.mas.maraimbekov.gamingelectronicstore.model;

public enum OrderStatus {
    UNFINISHED,
    NEW,
    APPROVED,
    DENIED,
    IN_PROGRESS,
    DELIVERED
}
