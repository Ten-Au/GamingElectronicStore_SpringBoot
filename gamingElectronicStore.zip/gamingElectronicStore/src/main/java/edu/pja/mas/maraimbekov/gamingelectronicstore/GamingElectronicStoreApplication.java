package edu.pja.mas.maraimbekov.gamingelectronicstore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GamingElectronicStoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(GamingElectronicStoreApplication.class, args);
	}

}
