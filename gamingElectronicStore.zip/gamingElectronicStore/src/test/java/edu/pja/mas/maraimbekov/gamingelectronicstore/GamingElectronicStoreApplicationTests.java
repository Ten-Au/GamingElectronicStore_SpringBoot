package edu.pja.mas.maraimbekov.gamingelectronicstore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GamingElectronicStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
